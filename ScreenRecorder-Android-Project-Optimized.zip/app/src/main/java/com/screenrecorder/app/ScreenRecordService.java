package com.screenrecorder.app;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.documentfile.provider.DocumentFile;
import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ScreenRecordService extends Service {
    private static final String CHANNEL = "screen_recording";
    private MediaProjection projection;
    private VirtualDisplay display;
    private MediaCodec videoEncoder, audioEncoder;
    private AudioRecord audioRecord;
    private Surface inputSurface;
    private MediaMuxer muxer;
    private int videoTrack = -1, audioTrack = -1;
    private boolean muxerStarted = false, recording = false;
    private Thread worker;
    private WindowManager windowManager;
    private View overlay;
    private Uri folderUri;
    private int fps, targetHeight;
    private float opacity;
    private int width, height;
    private long audioPtsUs = 0;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(7, notification("Подготовка записи…"));
        try {
            int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
            Intent projectionData = intent.getParcelableExtra("projectionData");
            folderUri = Uri.parse(intent.getStringExtra("folderUri"));
            fps = intent.getIntExtra("fps", 60);
            targetHeight = intent.getIntExtra("height", 1080);
            opacity = intent.getFloatExtra("opacity", .7f);
            MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mgr.getMediaProjection(resultCode, projectionData);
            if (projection == null) throw new IllegalStateException("MediaProjection недоступен");
            // Android 14+ requires a callback to be registered before creating a VirtualDisplay.
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopRecording(); }
            }, new Handler(Looper.getMainLooper()));
            startRecording();
            showOverlay();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка записи: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startRecording() throws Exception {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenW = dm.widthPixels, screenH = dm.heightPixels;
        float scale = Math.min(1f, targetHeight / (float)Math.max(screenW, screenH));
        width = even((int)(screenW * scale));
        height = even((int)(screenH * scale));
        // Keep the requested landscape/portrait aspect ratio of the current screen.
        MediaFormat vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        vf.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(5_000_000, width * height * fps / 12));
        vf.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        inputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();

        MediaFormat af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 48000, 2);
        af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        af.setInteger(MediaFormat.KEY_BIT_RATE, 192000);
        af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();

        AudioPlaybackCaptureConfiguration captureConfig =
            new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
                .addMatchingUsage(android.media.AudioAttributes.USAGE_UNKNOWN)
                .build();
        int minBuffer = AudioRecord.getMinBufferSize(48000,
            android.media.AudioFormat.CHANNEL_IN_STEREO, android.media.AudioFormat.ENCODING_PCM_16BIT);
        audioRecord = new AudioRecord.Builder()
            .setAudioFormat(new android.media.AudioFormat.Builder()
                .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(android.media.AudioFormat.CHANNEL_IN_STEREO).build())
            .setBufferSizeInBytes(Math.max(minBuffer * 2, 16384))
            .setAudioPlaybackCaptureConfig(captureConfig)
            .build();
        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED)
            throw new IllegalStateException("Не удалось открыть захват внутреннего звука");

        DocumentFile dir = DocumentFile.fromTreeUri(this, folderUri);
        if (dir == null || !dir.canWrite()) throw new IllegalStateException("Нет доступа к папке");
        String name = "Screen_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        DocumentFile file = dir.createFile("video/mp4", name);
        if (file == null) throw new IllegalStateException("Не удалось создать видеофайл");
        android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(file.getUri(), "rw");
        if (pfd == null) throw new IllegalStateException("Не удалось открыть видеофайл");
        muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        // Keep the descriptor alive until the muxer is stopped.
        descriptor = pfd;

        display = projection.createVirtualDisplay("ScreenRecorder", width, height,
            dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface, null, null);
        audioRecord.startRecording();
        recording = true;
        worker = new Thread(this::recordLoop, "screen-recorder-encoder");
        worker.start();
    }

    private android.os.ParcelFileDescriptor descriptor;

    private void recordLoop() {
        MediaCodec.BufferInfo vi = new MediaCodec.BufferInfo();
        MediaCodec.BufferInfo ai = new MediaCodec.BufferInfo();
        byte[] pcm = new byte[4096];
        long lastVideoDrain = 0;
        try {
            while (recording) {
                int read = audioRecord.read(pcm, 0, pcm.length);
                if (read > 0) feedAudio(pcm, read);
                drain(videoEncoder, vi, true, false);
                drain(audioEncoder, ai, false, false);
            }
            // Signal end-of-stream to both encoders so MP4 metadata can be finalized.
            try { videoEncoder.signalEndOfInputStream(); } catch (Exception ignored) {}
            int in = audioEncoder.dequeueInputBuffer(10000);
            if (in >= 0) audioEncoder.queueInputBuffer(in, 0, 0, audioPtsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            drain(videoEncoder, vi, true, true);
            drain(audioEncoder, ai, false, true);
        } catch (Exception e) {
            android.util.Log.e("ScreenRecorder", "Encoder loop failed", e);
        } finally {
            cleanupRecording();
        }
    }

    private void feedAudio(byte[] pcm, int size) {
        try {
            int index = audioEncoder.dequeueInputBuffer(10000);
            if (index < 0) return;
            java.nio.ByteBuffer input = audioEncoder.getInputBuffer(index);
            if (input == null) return;
            input.clear();
            int n = Math.min(size, input.remaining());
            n -= n % 4; // 16-bit stereo frames
            input.put(pcm, 0, n);
            long pts = audioPtsUs;
            audioPtsUs += (long)(n / 4) * 1_000_000L / 48000L;
            audioEncoder.queueInputBuffer(index, 0, n, pts, 0);
        } catch (Exception e) {
            android.util.Log.w("ScreenRecorder", "Audio input skipped", e);
        }
    }

    private void drain(MediaCodec codec, MediaCodec.BufferInfo info, boolean video, boolean end) {
        while (true) {
            int out = codec.dequeueOutputBuffer(info, end ? 10000 : 0);
            if (out == MediaCodec.INFO_TRY_AGAIN_LATER) return;
            if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                MediaFormat f = codec.getOutputFormat();
                if (video) videoTrack = muxer.addTrack(f); else audioTrack = muxer.addTrack(f);
                if (!muxerStarted && videoTrack >= 0 && audioTrack >= 0) {
                    muxer.start();
                    muxerStarted = true;
                }
            } else if (out >= 0) {
                java.nio.ByteBuffer buffer = codec.getOutputBuffer(out);
                if (buffer != null && info.size > 0 && muxerStarted &&
                    (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                    buffer.position(info.offset);
                    buffer.limit(info.offset + info.size);
                    muxer.writeSampleData(video ? videoTrack : audioTrack, buffer, info);
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                codec.releaseOutputBuffer(out, false);
                if (eos) return;
            }
        }
    }

    private int even(int x) { return Math.max(2, x & ~1); }

    private void showOverlay() {
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(10, 5, 10, 5);
        box.setBackgroundColor(0xCC202938);
        TextView stop = new TextView(this);
        stop.setText("  ■ Стоп  ");
        stop.setTextColor(0xFFFFFFFF);
        stop.setTextSize(14);
        TextView dot = new TextView(this);
        dot.setText("●");
        dot.setTextColor(0xFFFF4A55);
        dot.setTextSize(18);
        box.addView(dot); box.addView(stop);
        box.setAlpha(opacity);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = 20; lp.y = 180;
        windowManager.addView(box, lp);
        overlay = box;

        box.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; long downAt;
            public boolean onTouch(View v, android.view.MotionEvent ev) {
                if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = ev.getRawX(); downY = ev.getRawY();
                    startX = lp.x; startY = lp.y; downAt = System.currentTimeMillis(); return true;
                }
                if (ev.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = startX + (int)(downX - ev.getRawX());
                    lp.y = startY + (int)(ev.getRawY() - downY);
                    windowManager.updateViewLayout(box, lp); return true;
                }
                if (ev.getAction() == MotionEvent.ACTION_UP) {
                    if (System.currentTimeMillis() - downAt < 250 &&
                        Math.abs(ev.getRawX() - downX) < 10 && Math.abs(ev.getRawY() - downY) < 10) stopRecording();
                    return true;
                }
                return true;
            }
        });
    }

    private void stopRecording() {
        recording = false;
        if (audioRecord != null) try { audioRecord.stop(); } catch (Exception ignored) {}
        if (worker == null) cleanupRecording();
    }

    private void cleanupRecording() {
        try { if (audioRecord != null) { audioRecord.release(); audioRecord = null; } } catch (Exception ignored) {}
        try { if (display != null) { display.release(); display = null; } } catch (Exception ignored) {}
        try { if (projection != null) { projection.stop(); projection = null; } } catch (Exception ignored) {}
        try { if (videoEncoder != null) { videoEncoder.stop(); videoEncoder.release(); videoEncoder = null; } } catch (Exception ignored) {}
        try { if (audioEncoder != null) { audioEncoder.stop(); audioEncoder.release(); audioEncoder = null; } } catch (Exception ignored) {}
        try { if (muxer != null) { if (muxerStarted) muxer.stop(); muxer.release(); muxer = null; } } catch (Exception ignored) {}
        try { if (descriptor != null) { descriptor.close(); descriptor = null; } } catch (Exception ignored) {}
        muxerStarted = false;
        try { if (overlay != null && windowManager != null) { windowManager.removeView(overlay); overlay = null; } } catch (Exception ignored) {}
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Notification notification(String msg) {
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("Screen Recorder")
            .setContentText(msg)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true).build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @Override public void onDestroy() {
        stopRecording();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
