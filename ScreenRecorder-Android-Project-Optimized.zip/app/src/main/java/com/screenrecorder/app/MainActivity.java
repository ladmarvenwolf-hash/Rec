package com.screenrecorder.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.documentfile.provider.DocumentFile;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 100;
    private static final int REQUEST_FOLDER = 101;
    private Uri folderUri;
    private Spinner fpsSpinner, resolutionSpinner;
    private SeekBar opacityBar;
    private TextView folderText, opacityText, statusText;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 28, 28, 28);
        page.setBackgroundColor(0xFF10141D);
        scroll.addView(page);

        TextView title = text("SCREEN RECORDER", 25, 0xFFFFFFFF);
        page.addView(title);
        page.addView(text("Запись экрана • внутренний звук • плавающее управление", 14, 0xFFB8C3D9));

        page.addView(label("Частота кадров"));
        fpsSpinner = spinner(new String[]{"60 FPS", "90 FPS", "120 FPS"});
        page.addView(fpsSpinner);

        page.addView(label("Разрешение"));
        resolutionSpinner = spinner(new String[]{"720p", "1080p", "1440p (2K)"});
        resolutionSpinner.setSelection(1);
        page.addView(resolutionSpinner);

        page.addView(label("Прозрачность плавающего окна"));
        opacityText = text("70%", 15, 0xFFFFFFFF);
        page.addView(opacityText);
        opacityBar = new SeekBar(this);
        opacityBar.setMax(80);
        opacityBar.setProgress(50);
        page.addView(opacityBar);
        opacityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                opacityText.setText((20 + p) + "%");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        Button folderButton = button("Выбрать папку для видео");
        page.addView(folderButton);
        folderText = text("Папка не выбрана", 13, 0xFFFFD27A);
        page.addView(folderText);
        folderButton.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQUEST_FOLDER);
        });

        Button overlayButton = button("Разрешить плавающее окно");
        page.addView(overlayButton);
        overlayButton.setOnClickListener(v -> {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show();
        });

        Button startButton = button("●  НАЧАТЬ ЗАПИСЬ");
        page.addView(startButton);
        startButton.setOnClickListener(v -> startCapture());

        statusText = text("Перед началом выберите папку и разрешите плавающее окно.", 13, 0xFFB8C3D9);
        page.addView(statusText);
        page.addView(text("Примечание: фактические FPS зависят от дисплея и устройства. Внутренний звук доступен на Android 10+ и только для приложений, разрешающих захват.", 12, 0xFF9BA8BD));
        setContentView(scroll);
    }

    private void startCapture() {
        if (folderUri == null) {
            Toast.makeText(this, "Сначала выберите папку", Toast.LENGTH_LONG).show();
            return;
        }
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разрешите плавающее окно", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_FOLDER) {
            folderUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(folderUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {}
            DocumentFile dir = DocumentFile.fromTreeUri(this, folderUri);
            folderText.setText(dir != null ? "Папка: " + dir.getName() : "Папка выбрана");
        } else if (requestCode == REQUEST_CAPTURE) {
            Intent service = new Intent(this, ScreenRecordService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("projectionData", data);
            service.putExtra("folderUri", folderUri.toString());
            service.putExtra("fps", new int[]{60,90,120}[fpsSpinner.getSelectedItemPosition()]);
            service.putExtra("height", new int[]{720,1080,1440}[resolutionSpinner.getSelectedItemPosition()]);
            service.putExtra("opacity", (20 + opacityBar.getProgress()) / 100f);
            try {
                startForegroundService(service);
                statusText.setText("Запись запущена. Управляйте ею через плавающее окно.");
            } catch (Exception e) {
                statusText.setText("Не удалось начать запись: " + e.getMessage());
            }
        }
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, 8, 0, 8); return t;
    }
    private TextView label(String s) {
        TextView t = text(s, 17, 0xFFFFFFFF); t.setPadding(0, 20, 0, 6); return t;
    }
    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, values));
        return s;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = 10;
        b.setLayoutParams(p); return b;
    }
}
